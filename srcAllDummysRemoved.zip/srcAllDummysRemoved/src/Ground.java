// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public final class Ground extends Node {

	public Ground(int i, int j, int k)
	{
		obj5Array = new Object5[5];
		anIntArray1319 = new int[5];
		anInt1310 = anInt1307 = i;
		anInt1308 = j;
		anInt1309 = k;
	}

	int anInt1307;
	final int anInt1308;
	final int anInt1309;
	final int anInt1310;
	public Class43 aClass43_1311;
	public Class40 aClass40_1312;
	public Object1 obj1;
	public Object2 obj2;
	public Object3 obj3;
	public Object4 obj4;
	int anInt1317;
	public final Object5[] obj5Array;
	final int[] anIntArray1319;
	int anInt1320;
	int anInt1321;
	boolean aBoolean1322;
	boolean aBoolean1323;
	boolean aBoolean1324;
	int anInt1325;
	int anInt1326;
	int anInt1327;
	int anInt1328;
	public Ground aClass30_Sub3_1329;
}
