// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


final class Class43
{

	public Class43(int i, int j, int k, int l, int i1, int j1, boolean flag)
	{
		aBoolean721 = true;
		anInt716 = i;
		anInt717 = j;
		anInt718 = k;
		anInt719 = l;
		anInt720 = i1;
		anInt722 = j1;
		aBoolean721 = flag;
	}

	final int anInt716;
	final int anInt717;
	final int anInt718;
	final int anInt719;
	final int anInt720;
	boolean aBoolean721;
	final int anInt722;
}
