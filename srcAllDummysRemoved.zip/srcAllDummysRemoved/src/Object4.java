// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


final class Object4 {

	Object4()
	{
	}

	int anInt45;
	int anInt46;
	int anInt47;
	Animable aClass30_Sub2_Sub4_48;
	Animable aClass30_Sub2_Sub4_49;
	Animable aClass30_Sub2_Sub4_50;
	int uid;
	int anInt52;
}
